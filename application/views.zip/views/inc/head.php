<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
		<meta name="author" content="Magnus Immigration"/>	
		<meta name="description" content="Magnus Immigration - Canada -  Australia"/>
		<meta name="keywords" content="Magnus Immigration - Canada -  Australia, Coaching, Consulting, Creative, Immigration, Visa">	
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
				
  		<!-- SITE TITLE -->
		<title>Magnus Immigration - Canada -  Australia</title>
							
		<!-- FAVICON AND TOUCH ICONS  -->
		<link rel="shortcut icon" href="<?php echo base_url();?>assets/images/magnus/magnus-immigration-fevi.png" type="image/x-icon">
		<link rel="icon" href="<?php echo base_url();?>assets/images/magnus/magnus-immigration-fevi.png" type="image/x-icon">

		<!-- GOOGLE FONTS -->
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet"> 	
		<link href="https://fonts.googleapis.com/css?family=Muli:400,600,700,800,900&amp;display=swap" rel="stylesheet">

		<!-- BOOTSTRAP CSS -->
		<link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
		
        <link href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"  rel="stylesheet" >
        		
		<!-- FONT ICONS -->
		<link href="<?php echo base_url();?>assets/css/all.css" rel="stylesheet" >		
		<link href="<?php echo base_url();?>assets/css/flaticon.css" rel="stylesheet">

		<!-- PLUGINS STYLESHEET -->
		<link href="<?php echo base_url();?>assets/css/menu.css" rel="stylesheet">	
		<link id="effect" href="<?php echo base_url();?>assets/css/dropdown-effects/fade-down.css" media="all" rel="stylesheet">
		<link href="<?php echo base_url();?>assets/css/tweenmax.css" rel="stylesheet">	
		<link href="<?php echo base_url();?>assets/css/magnific-popup.css" rel="stylesheet">	
		<link href="<?php echo base_url();?>assets/css/owl.carousel.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>assets/css/owl.theme.default.min.css" rel="stylesheet">
	
		<!-- TEMPLATE CSS -->
		<link href="<?php echo base_url();?>assets/css/red.css" rel="stylesheet">

		<!-- STYLE SWITCHER CSS -->	
		
		<!-- RESPONSIVE CSS -->
		<link href="<?php echo base_url();?>assets/css/responsive.css" rel="stylesheet"> 
<style type="text/css">
	.foo-links {
    display: inline-block;
    padding-left: 0;
    margin: 0 auto 0;
}
.wsmenu > .wsmenu-list > li > .wsmegamenu .link-list li {
	white-space: normal;
}
.foo-socials {
    position: fixed;
    top: 25%;
    right: 0;
    list-style: none;
    padding-left: 0;
    z-index: 10;
    margin: 0;
    transition: right 0.25s ease-in-out;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column;
}
.foo-socials a {
    display: block;
    text-align: center;
    padding: px;
    transition: all 0.3s ease;
    color: #fff;
    font-size: 20px;
}
.foo-socials .ico-facebook {
    background: #3B5998;
}
.foo-socials .ico-instagram {
    background: #dd4b39;
}
.foo-socials .ico-youtube {
    background: #b00;
}
.foo-socials .ico-whatsapp {
    background: #25D366;
}

</style>